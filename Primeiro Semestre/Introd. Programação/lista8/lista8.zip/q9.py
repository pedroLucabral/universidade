def soma(n1, n2, n3):
    return n1 + n2 + n3

num1 = int(input("Digite um número: "))
num2 = int(input("Digite um número: "))
num3 = int(input("Digite um número: "))

print(soma(num1, num2, num3))