def tamanho(n):
    return len(str(n))