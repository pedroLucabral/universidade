def posNeg(n):
    return "P" if n > 0 else "N"
