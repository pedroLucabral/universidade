str1 = input("Digite sua frase: ")

for i in range(len(str1) + 1):
    print(str1[:i])

