n = int(input("Digite um número: "))

for i in range(n + 1):
    print((str(i)  + " ")* i)