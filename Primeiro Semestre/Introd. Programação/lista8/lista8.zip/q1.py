str1 = "abcde"
str2 = "fghijk"

print(f"String 1: {str1}\nString 2: {str2}")
print("As string tem o mesmo comprimento" if len(str1) == len(str2) else "")
print("As strings são iguais" if str1 == str2 else "")
