raio = float(input("Digite o raio do circulo: "))

print(f"A area e: {3.14*raio**2:.2f}")