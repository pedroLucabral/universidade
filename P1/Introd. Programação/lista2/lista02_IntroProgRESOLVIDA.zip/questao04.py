turno = input("Qual turno voce estuda?\nM (Matutino)\nV (Vespertino)\nN (Noturno)\n").upper()

match turno:
    case "M":
        print("Bom dia!")
    case "V":
        print("Boa tarde!")
    case "N":
        print("Boa noite!")
    case _:
        print("Valor Invalido")