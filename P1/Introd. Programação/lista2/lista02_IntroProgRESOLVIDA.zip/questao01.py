import math

raio = float(input("Digite o raio do circulo: "))

print(f"A area e: {math.pi*raio**2:.2f}")