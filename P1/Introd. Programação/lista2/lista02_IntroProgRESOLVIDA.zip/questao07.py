valor = float(input("Digite o valor da compra: "))
metodo_pgmt = input("Digite o metodo de pagamento: ").lower()

match metodo_pgmt:
    case "dinheiro":
        if valor >= 100:
            print(f"Valor total: {valor-(valor*0.1)}")
        else:
            print(f"Valor total: {valor}")
    case "cheque":
        print(f"Valor total: {valor}")
    case _:
        print("Forma de pagamento invalida")