valor = float(input("Digite o valor da compra: "))
metodo_pgmt = input("Digite o metodo de pagamento: ").lower()

match metodo_pgmt:
    case "dinheiro":
        if valor >= 100:
            print(f"Valor total: R${valor-(valor*0.1)}")
        else:
            print(f"Valor total: R${valor}")
    case "cheque":
        print(f"Valor total: R${valor}")
    case "cartao":
        debt_or_credit = input("Digite se quer pagar com credito ou debito: ").lower()
        match debt_or_credit:
            case "credito":
                parcelas = int(input("Em quantas vezes deseja dividir? (Limite de 3)"))
                if parcelas > 1 and parcelas < 4:
                    print(f"Valor total: R${valor}\n{parcelas} parcela(s) de {valor/parcelas}")
                elif parcelas > 3:
                    print("Quantidade de parcelas invalida")
                else:
                    print(f"Valor total: R${valor}")
            case "debito":
                print(f"Valor total: {valor}")
    case _:
        print("Forma de pagamento invalida")