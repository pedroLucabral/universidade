v1 = [1,2,3,4,5]
v2 = [6,7,8,9,10]

v3 = []

for i in range(5):
    v3.append(v1[i])
    v3.append(v2[i])

print(v3)